# plugin.video.thvli - phần mở rộng kodi 18

Hỗ trợ xem lại các phim đã phát trên kênh truyền hình vĩnh long việt nam. Phần mở rộng này không chịu bất cứ trách nhiệm nào có liên quan.

## Yêu cầu
- Kodi 18
- requests
- [inputstream.adaptive](https://github.com/peak3d/inputstream.adaptive)

## Cài đặt

- Bấm vào nút Clone > Download ZIP. Lưu về máy.
- Vào phần SYSTEM > Add-on > Install from zip file. Chọn tên tập tin zip vừa mới tải về.
 - Sau đó kodi sẽ tự cài đặt.